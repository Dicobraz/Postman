@echo off
echo collect
